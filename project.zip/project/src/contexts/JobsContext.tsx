import React, { createContext, useState, useEffect, useContext } from 'react';
import { Job } from '../types';
import { getJobs, setJobs, addNotification } from '../utils/localStorage';

interface JobsContextType {
  jobs: Job[];
  loading: boolean;
  getJobById: (id: string) => Job | undefined;
  getJobsByShipId: (shipId: string) => Job[];
  getJobsByComponentId: (componentId: string) => Job[];
  getJobsByDate: (date: string) => Job[];
  addJob: (job: Omit<Job, 'id'>) => void;
  updateJob: (id: string, updatedJob: Partial<Job>) => void;
  deleteJob: (id: string) => void;
}

const JobsContext = createContext<JobsContextType | undefined>(undefined);

export const JobsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [jobs, setJobsState] = useState<Job[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load jobs from localStorage
    const loadedJobs = getJobs();
    setJobsState(loadedJobs);
    setLoading(false);
  }, []);

  const getJobById = (id: string) => {
    return jobs.find(job => job.id === id);
  };

  const getJobsByShipId = (shipId: string) => {
    return jobs.filter(job => job.shipId === shipId);
  };

  const getJobsByComponentId = (componentId: string) => {
    return jobs.filter(job => job.componentId === componentId);
  };

  const getJobsByDate = (date: string) => {
    // Compare only the date part (YYYY-MM-DD)
    const targetDate = date.split('T')[0];
    return jobs.filter(job => {
      const jobDate = job.scheduledDate.split('T')[0];
      return jobDate === targetDate;
    });
  };

  const addJob = (job: Omit<Job, 'id'>) => {
    const newJob: Job = {
      ...job,
      id: `j${Date.now()}`
    };
    
    const updatedJobs = [...jobs, newJob];
    setJobsState(updatedJobs);
    setJobs(updatedJobs);
    
    // Add notification for new job
    addNotification(
      'Job Created', 
      `New ${job.type} job scheduled for ${job.scheduledDate.split('T')[0]}`,
      newJob.id
    );
  };

  const updateJob = (id: string, updatedJob: Partial<Job>) => {
    const existingJob = jobs.find(job => job.id === id);
    if (!existingJob) return;
    
    const updatedJobs = jobs.map(job => 
      job.id === id ? { ...job, ...updatedJob } : job
    );
    
    setJobsState(updatedJobs);
    setJobs(updatedJobs);
    
    // Add notification based on status change
    if (updatedJob.status) {
      if (updatedJob.status === 'Completed') {
        addNotification(
          'Job Completed', 
          `${existingJob.type} job has been completed`,
          id
        );
      } else if (updatedJob.status !== existingJob.status) {
        addNotification(
          'Job Updated', 
          `${existingJob.type} job status updated to ${updatedJob.status}`,
          id
        );
      }
    }
  };

  const deleteJob = (id: string) => {
    const updatedJobs = jobs.filter(job => job.id !== id);
    setJobsState(updatedJobs);
    setJobs(updatedJobs);
  };

  return (
    <JobsContext.Provider 
      value={{ 
        jobs, 
        loading, 
        getJobById, 
        getJobsByShipId,
        getJobsByComponentId,
        getJobsByDate,
        addJob, 
        updateJob, 
        deleteJob 
      }}
    >
      {children}
    </JobsContext.Provider>
  );
};

export const useJobs = (): JobsContextType => {
  const context = useContext(JobsContext);
  if (context === undefined) {
    throw new Error('useJobs must be used within a JobsProvider');
  }
  return context;
};