import React, { createContext, useState, useEffect, useContext } from 'react';
import { Ship } from '../types';
import { getShips, setShips } from '../utils/localStorage';

interface ShipsContextType {
  ships: Ship[];
  loading: boolean;
  getShipById: (id: string) => Ship | undefined;
  addShip: (ship: Omit<Ship, 'id'>) => void;
  updateShip: (id: string, updatedShip: Partial<Ship>) => void;
  deleteShip: (id: string) => void;
}

const ShipsContext = createContext<ShipsContextType | undefined>(undefined);

export const ShipsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [ships, setShipsState] = useState<Ship[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load ships from localStorage
    const loadedShips = getShips();
    setShipsState(loadedShips);
    setLoading(false);
  }, []);

  const getShipById = (id: string) => {
    return ships.find(ship => ship.id === id);
  };

  const addShip = (ship: Omit<Ship, 'id'>) => {
    const newShip: Ship = {
      ...ship,
      id: `s${Date.now()}`
    };
    
    const updatedShips = [...ships, newShip];
    setShipsState(updatedShips);
    setShips(updatedShips);
  };

  const updateShip = (id: string, updatedShip: Partial<Ship>) => {
    const updatedShips = ships.map(ship => 
      ship.id === id ? { ...ship, ...updatedShip } : ship
    );
    
    setShipsState(updatedShips);
    setShips(updatedShips);
  };

  const deleteShip = (id: string) => {
    const updatedShips = ships.filter(ship => ship.id !== id);
    setShipsState(updatedShips);
    setShips(updatedShips);
  };

  return (
    <ShipsContext.Provider 
      value={{ 
        ships, 
        loading, 
        getShipById, 
        addShip, 
        updateShip, 
        deleteShip 
      }}
    >
      {children}
    </ShipsContext.Provider>
  );
};

export const useShips = (): ShipsContextType => {
  const context = useContext(ShipsContext);
  if (context === undefined) {
    throw new Error('useShips must be used within a ShipsProvider');
  }
  return context;
};