import React, { createContext, useState, useEffect, useContext } from 'react';
import { Component } from '../types';
import { getComponents, setComponents } from '../utils/localStorage';

interface ComponentsContextType {
  components: Component[];
  loading: boolean;
  getComponentById: (id: string) => Component | undefined;
  getComponentsByShipId: (shipId: string) => Component[];
  addComponent: (component: Omit<Component, 'id'>) => string;
  updateComponent: (id: string, updatedComponent: Partial<Component>) => void;
  deleteComponent: (id: string) => void;
}

const ComponentsContext = createContext<ComponentsContextType | undefined>(undefined);

export const ComponentsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [components, setComponentsState] = useState<Component[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load components from localStorage
    const loadedComponents = getComponents();
    setComponentsState(loadedComponents);
    setLoading(false);
  }, []);

  const getComponentById = (id: string) => {
    return components.find(component => component.id === id);
  };

  const getComponentsByShipId = (shipId: string) => {
    return components.filter(component => component.shipId === shipId);
  };

  const addComponent = (component: Omit<Component, 'id'>) => {
    const newId = `c${Date.now()}`;
    const newComponent: Component = {
      ...component,
      id: newId
    };
    
    const updatedComponents = [...components, newComponent];
    setComponentsState(updatedComponents);
    setComponents(updatedComponents);
    return newId;
  };

  const updateComponent = (id: string, updatedComponent: Partial<Component>) => {
    const updatedComponents = components.map(component => 
      component.id === id ? { ...component, ...updatedComponent } : component
    );
    
    setComponentsState(updatedComponents);
    setComponents(updatedComponents);
  };

  const deleteComponent = (id: string) => {
    const updatedComponents = components.filter(component => component.id !== id);
    setComponentsState(updatedComponents);
    setComponents(updatedComponents);
  };

  return (
    <ComponentsContext.Provider 
      value={{ 
        components, 
        loading, 
        getComponentById, 
        getComponentsByShipId,
        addComponent, 
        updateComponent, 
        deleteComponent 
      }}
    >
      {children}
    </ComponentsContext.Provider>
  );
};

export const useComponents = (): ComponentsContextType => {
  const context = useContext(ComponentsContext);
  if (context === undefined) {
    throw new Error('useComponents must be used within a ComponentsProvider');
  }
  return context;
};