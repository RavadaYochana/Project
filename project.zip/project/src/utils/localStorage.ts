import { User, Ship, Component, Job, Notification } from '../types';

// Initial mock data
const initialData = {
  users: [
    { id: '1', role: 'Admin', email: 'admin@entnt.in', password: 'admin123' },
    { id: '2', role: 'Inspector', email: 'inspector@entnt.in', password: 'inspect123' },
    { id: '3', role: 'Engineer', email: 'engineer@entnt.in', password: 'engine123' }
  ],
  ships: [
    { id: 's1', name: 'Ever Given', imo: '9811000', flag: 'Panama', status: 'Active' },
    { id: 's2', name: 'Maersk Alabama', imo: '9164263', flag: 'USA', status: 'Under Maintenance' }
  ],
  components: [
    { 
      id: 'c1', 
      shipId: 's1', 
      name: 'Main Engine', 
      serialNumber: 'ME-1234',
      installDate: '2020-01-10', 
      lastMaintenanceDate: '2024-03-12' 
    },
    { 
      id: 'c2', 
      shipId: 's2', 
      name: 'Radar', 
      serialNumber: 'RAD-5678', 
      installDate: '2021-07-18', 
      lastMaintenanceDate: '2023-12-01' 
    }
  ],
  jobs: [
    { 
      id: 'j1', 
      componentId: 'c1', 
      shipId: 's1', 
      type: 'Inspection', 
      priority: 'High',
      status: 'Open', 
      assignedEngineerId: '3', 
      scheduledDate: '2025-05-05' 
    }
  ],
  notifications: []
};

// Helper to initialize localStorage with mock data if it doesn't exist
export const initializeLocalStorage = () => {
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify(initialData.users));
  }
  if (!localStorage.getItem('ships')) {
    localStorage.setItem('ships', JSON.stringify(initialData.ships));
  }
  if (!localStorage.getItem('components')) {
    localStorage.setItem('components', JSON.stringify(initialData.components));
  }
  if (!localStorage.getItem('jobs')) {
    localStorage.setItem('jobs', JSON.stringify(initialData.jobs));
  }
  if (!localStorage.getItem('notifications')) {
    localStorage.setItem('notifications', JSON.stringify(initialData.notifications));
  }
};

// Generic function to get items from localStorage
export const getItems = <T>(key: string): T[] => {
  const items = localStorage.getItem(key);
  return items ? JSON.parse(items) : [];
};

// Generic function to set items in localStorage
export const setItems = <T>(key: string, items: T[]): void => {
  localStorage.setItem(key, JSON.stringify(items));
};

// User specific functions
export const getUsers = (): User[] => getItems<User>('users');
export const setUsers = (users: User[]): void => setItems('users', users);

// Ship specific functions
export const getShips = (): Ship[] => getItems<Ship>('ships');
export const setShips = (ships: Ship[]): void => setItems('ships', ships);

// Component specific functions
export const getComponents = (): Component[] => getItems<Component>('components');
export const setComponents = (components: Component[]): void => setItems('components', components);

// Job specific functions
export const getJobs = (): Job[] => getItems<Job>('jobs');
export const setJobs = (jobs: Job[]): void => setItems('jobs', jobs);

// Notification specific functions
export const getNotifications = (): Notification[] => getItems<Notification>('notifications');
export const setNotifications = (notifications: Notification[]): void => setItems('notifications', notifications);

// Authentication functions
export const setCurrentUser = (user: User): void => {
  localStorage.setItem('currentUser', JSON.stringify(user));
};

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem('currentUser');
  return user ? JSON.parse(user) : null;
};

export const removeCurrentUser = (): void => {
  localStorage.removeItem('currentUser');
};

// Helper to add a new notification
export const addNotification = (type: 'Job Created' | 'Job Updated' | 'Job Completed', message: string, relatedId?: string): void => {
  const notifications = getNotifications();
  const newNotification: Notification = {
    id: `n${Date.now()}`,
    type,
    message,
    date: new Date().toISOString(),
    read: false,
    relatedId
  };
  
  setNotifications([newNotification, ...notifications]);
};