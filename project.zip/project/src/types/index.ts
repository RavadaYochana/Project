export interface User {
  id: string;
  role: 'Admin' | 'Inspector' | 'Engineer';
  email: string;
  password: string;
}

export interface Ship {
  id: string;
  name: string;
  imo: string;
  flag: string;
  status: 'Active' | 'Under Maintenance' | 'Inactive';
}

export interface Component {
  id: string;
  shipId: string;
  name: string;
  serialNumber: string;
  installDate: string;
  lastMaintenanceDate: string;
}

export interface Job {
  id: string;
  componentId: string;
  shipId: string;
  type: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'Open' | 'In Progress' | 'Completed';
  assignedEngineerId: string;
  scheduledDate: string;
}

export interface Notification {
  id: string;
  type: 'Job Created' | 'Job Updated' | 'Job Completed';
  message: string;
  date: string;
  read: boolean;
  relatedId?: string;
}