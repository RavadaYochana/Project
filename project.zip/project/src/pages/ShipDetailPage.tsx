import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Ship as ShipIcon, Edit, Trash2, Plus, ArrowLeft } from 'lucide-react';
import { useShips } from '../contexts/ShipsContext';
import { useComponents } from '../contexts/ComponentsContext';
import { useJobs } from '../contexts/JobsContext';
import Button from '../components/ui/Button';
import ShipForm from '../components/ships/ShipForm';
import ComponentList from '../components/components/ComponentList';
import ComponentForm from '../components/components/ComponentForm';
import JobForm from '../components/jobs/JobForm';
import JobList from '../components/jobs/JobList';

const ShipDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { ships, getShipById, updateShip, deleteShip } = useShips();
  const { components, getComponentsByShipId, getComponentById, addComponent, updateComponent, deleteComponent } = useComponents();
  const { jobs, getJobsByShipId, getJobById, addJob, updateJob, deleteJob } = useJobs();
  
  const [showEditShip, setShowEditShip] = useState(false);
  const [showAddComponent, setShowAddComponent] = useState(false);
  const [editingComponent, setEditingComponent] = useState<string | null>(null);
  const [showAddJob, setShowAddJob] = useState(false);
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
  const [editingJob, setEditingJob] = useState<string | null>(null);
  
  if (!id) {
    return (
      <div className="text-center p-8">
        <p className="text-red-500">Ship ID is missing</p>
        <button
          onClick={() => navigate('/ships')}
          className="mt-4 text-blue-600 hover:text-blue-800"
        >
          Go back to Ships
        </button>
      </div>
    );
  }

  const ship = getShipById(id);
  
  if (!ship) {
    return (
      <div className="text-center p-8">
        <p className="text-red-500">Ship not found</p>
        <button
          onClick={() => navigate('/ships')}
          className="mt-4 text-blue-600 hover:text-blue-800"
        >
          Go back to Ships
        </button>
      </div>
    );
  }

  const shipComponents = getComponentsByShipId(id);
  const shipJobs = getJobsByShipId(id);

  const handleEditShip = (data: Omit<typeof ship, 'id'>) => {
    updateShip(id, data);
    setShowEditShip(false);
  };

  const handleDeleteShip = () => {
    if (window.confirm('Are you sure you want to delete this ship?')) {
      deleteShip(id);
      navigate('/ships');
    }
  };

  const handleAddComponent = (data: Omit<typeof components[0], 'id'>) => {
    addComponent(data);
    setShowAddComponent(false);
  };

  const handleEditComponent = (componentId: string) => {
    setEditingComponent(componentId);
    setShowAddComponent(true);
  };

  const handleUpdateComponent = (data: Omit<typeof components[0], 'id'>) => {
    if (editingComponent) {
      updateComponent(editingComponent, data);
      setEditingComponent(null);
      setShowAddComponent(false);
    }
  };

  const handleDeleteComponent = (componentId: string) => {
    if (window.confirm('Are you sure you want to delete this component?')) {
      deleteComponent(componentId);
    }
  };

  const handleAddJobClick = (componentId?: string) => {
    setSelectedComponentId(componentId || null);
    setShowAddJob(true);
  };

  const handleAddJob = (data: Omit<typeof jobs[0], 'id'>) => {
    addJob(data);
    setShowAddJob(false);
    setSelectedComponentId(null);
  };

  const handleEditJob = (jobId: string) => {
    setEditingJob(jobId);
    setShowAddJob(true);
  };

  const handleUpdateJob = (data: Omit<typeof jobs[0], 'id'>) => {
    if (editingJob) {
      updateJob(editingJob, data);
      setEditingJob(null);
      setShowAddJob(false);
    }
  };

  const handleDeleteJob = (jobId: string) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      deleteJob(jobId);
    }
  };

  // Status colors
  const statusColors = {
    'Active': 'bg-green-100 text-green-800',
    'Under Maintenance': 'bg-yellow-100 text-yellow-800',
    'Inactive': 'bg-red-100 text-red-800'
  };

  return (
    <div>
      <div className="mb-6">
        <button
          onClick={() => navigate('/ships')}
          className="flex items-center text-blue-600 hover:text-blue-800 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Ships
        </button>
        
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="flex items-start">
            <ShipIcon className="h-8 w-8 text-blue-600 mr-3 mt-1" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{ship.name}</h1>
              <div className="flex flex-wrap items-center gap-2 mt-1">
                <span className="text-gray-600">IMO: {ship.imo}</span>
                <span className="text-gray-600">•</span>
                <span className="text-gray-600">Flag: {ship.flag}</span>
                <span className="text-gray-600">•</span>
                <span className={`text-xs px-2 py-1 rounded-full ${statusColors[ship.status as keyof typeof statusColors]}`}>
                  {ship.status}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex mt-4 md:mt-0 space-x-2">
            <Button
              onClick={() => setShowEditShip(!showEditShip)}
              variant="secondary"
              icon={<Edit className="h-4 w-4" />}
            >
              Edit
            </Button>
            <Button
              onClick={handleDeleteShip}
              variant="danger"
              icon={<Trash2 className="h-4 w-4" />}
            >
              Delete
            </Button>
          </div>
        </div>
      </div>

      {showEditShip && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Edit Ship</h2>
          <ShipForm
            initialData={ship}
            onSubmit={handleEditShip}
            isEdit
          />
        </div>
      )}
      
      {/* Components Section */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Components</h2>
          <Button
            onClick={() => {
              setEditingComponent(null);
              setShowAddComponent(!showAddComponent);
            }}
            variant="primary"
            icon={<Plus className="h-4 w-4" />}
            size="sm"
          >
            Add Component
          </Button>
        </div>
        
        {showAddComponent && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              {editingComponent ? 'Edit Component' : 'Add New Component'}
            </h3>
            <ComponentForm
              shipId={id}
              initialData={editingComponent ? getComponentById(editingComponent) : undefined}
              onSubmit={editingComponent ? handleUpdateComponent : handleAddComponent}
              isEdit={!!editingComponent}
            />
          </div>
        )}
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <ComponentList
            components={shipComponents}
            onEdit={handleEditComponent}
            onDelete={handleDeleteComponent}
            onAddJob={handleAddJobClick}
          />
        </div>
      </div>
      
      {/* Maintenance Jobs Section */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Maintenance Jobs</h2>
          <Button
            onClick={() => {
              setEditingJob(null);
              setSelectedComponentId(null);
              setShowAddJob(!showAddJob);
            }}
            variant="primary"
            icon={<Plus className="h-4 w-4" />}
            size="sm"
          >
            Schedule Job
          </Button>
        </div>
        
        {showAddJob && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              {editingJob ? 'Edit Maintenance Job' : 'Schedule New Maintenance Job'}
            </h3>
            <JobForm
              shipId={id}
              componentId={selectedComponentId || undefined}
              initialData={editingJob ? getJobById(editingJob) : undefined}
              onSubmit={editingJob ? handleUpdateJob : handleAddJob}
              isEdit={!!editingJob}
            />
          </div>
        )}
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <JobList
            jobs={shipJobs}
            onEdit={handleEditJob}
            onDelete={handleDeleteJob}
          />
        </div>
      </div>
    </div>
  );
};

export default ShipDetailPage;