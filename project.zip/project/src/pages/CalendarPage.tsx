import React, { useState } from 'react';
import { Calendar as CalendarIcon, X } from 'lucide-react';
import Calendar from '../components/calendar/Calendar';
import { useJobs } from '../contexts/JobsContext';
import { Job } from '../types';
import { format } from 'date-fns';
import { useShips } from '../contexts/ShipsContext';
import { useComponents } from '../contexts/ComponentsContext';
import { getUsers } from '../utils/localStorage';

const CalendarPage: React.FC = () => {
  const { jobs } = useJobs();
  const { getShipById } = useShips();
  const { getComponentById } = useComponents();
  const users = getUsers();
  
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedJobs, setSelectedJobs] = useState<Job[]>([]);

  const handleDayClick = (date: Date, dayJobs: Job[]) => {
    setSelectedDate(date);
    setSelectedJobs(dayJobs);
  };

  // Helper to get component name
  const getComponentName = (componentId: string) => {
    const component = getComponentById(componentId);
    return component ? component.name : 'Unknown';
  };

  // Helper to get ship name
  const getShipName = (shipId: string) => {
    const ship = getShipById(shipId);
    return ship ? ship.name : 'Unknown';
  };

  // Helper to get engineer name
  const getEngineerName = (engineerId: string) => {
    const engineer = users.find(user => user.id === engineerId);
    return engineer ? engineer.email : 'Unknown';
  };

  // Helper for priority class
  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'Low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Helper for status class
  const getStatusClass = (status: string) => {
    switch (status) {
      case 'Open':
        return 'bg-blue-100 text-blue-800';
      case 'In Progress':
        return 'bg-purple-100 text-purple-800';
      case 'Completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          <CalendarIcon className="h-6 w-6 mr-2 text-blue-600" />
          Maintenance Calendar
        </h1>
        <p className="text-gray-600">View and manage scheduled maintenance jobs</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Calendar jobs={jobs} onDayClick={handleDayClick} />
        </div>
        
        <div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              {selectedDate 
                ? `Jobs for ${format(selectedDate, 'MMMM d, yyyy')}`
                : 'Select a date to view jobs'}
            </h2>
            
            {selectedDate && (
              <>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-gray-500">
                    {selectedJobs.length} {selectedJobs.length === 1 ? 'job' : 'jobs'} scheduled
                  </span>
                  {selectedJobs.length > 0 && (
                    <button
                      onClick={() => {
                        setSelectedDate(null);
                        setSelectedJobs([]);
                      }}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Clear
                    </button>
                  )}
                </div>
                
                {selectedJobs.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">
                    No jobs scheduled for this date
                  </p>
                ) : (
                  <div className="space-y-4">
                    {selectedJobs.map(job => (
                      <div key={job.id} className="border border-gray-200 rounded-md p-4 hover:bg-gray-50">
                        <div className="flex justify-between">
                          <h3 className="font-medium text-gray-900">{job.type}</h3>
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getPriorityClass(job.priority)}`}>
                              {job.priority}
                            </span>
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusClass(job.status)}`}>
                              {job.status}
                            </span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mt-2">
                          <span className="font-medium">Ship:</span> {getShipName(job.shipId)}
                        </p>
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Component:</span> {getComponentName(job.componentId)}
                        </p>
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Engineer:</span> {getEngineerName(job.assignedEngineerId)}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarPage;