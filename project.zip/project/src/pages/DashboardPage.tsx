import React from 'react';
import { Ship, BarChart, Users, PenTool as Tool, Activity } from 'lucide-react';
import KPICard from '../components/dashboard/KPICard';
import StatusChart from '../components/dashboard/StatusChart';
import { useShips } from '../contexts/ShipsContext';
import { useComponents } from '../contexts/ComponentsContext';
import { useJobs } from '../contexts/JobsContext';

const DashboardPage: React.FC = () => {
  const { ships } = useShips();
  const { components } = useComponents();
  const { jobs } = useJobs();

  // Calculate statistics
  const totalShips = ships.length;
  const activeShips = ships.filter(ship => ship.status === 'Active').length;
  const underMaintenanceShips = ships.filter(ship => ship.status === 'Under Maintenance').length;
  
  const totalComponents = components.length;
  
  // Check for components with overdue maintenance (more than 6 months)
  const componentsWithOverdueMaintenance = components.filter(component => {
    if (!component.lastMaintenanceDate) return true;
    
    const lastMaintenance = new Date(component.lastMaintenanceDate);
    const today = new Date();
    
    // Maintenance is overdue if it's been more than 6 months
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(today.getMonth() - 6);
    
    return lastMaintenance < sixMonthsAgo;
  }).length;
  
  const totalJobs = jobs.length;
  const openJobs = jobs.filter(job => job.status === 'Open').length;
  const inProgressJobs = jobs.filter(job => job.status === 'In Progress').length;
  const completedJobs = jobs.filter(job => job.status === 'Completed').length;
  
  const highPriorityJobs = jobs.filter(job => job.priority === 'High').length;
  const mediumPriorityJobs = jobs.filter(job => job.priority === 'Medium').length;
  const lowPriorityJobs = jobs.filter(job => job.priority === 'Low').length;

  // Status charts data
  const shipStatusData = [
    { label: 'Active', value: activeShips, color: 'bg-green-500' },
    { label: 'Under Maintenance', value: underMaintenanceShips, color: 'bg-yellow-500' },
    { label: 'Inactive', value: totalShips - activeShips - underMaintenanceShips, color: 'bg-red-500' }
  ];
  
  const jobStatusData = [
    { label: 'Open', value: openJobs, color: 'bg-blue-500' },
    { label: 'In Progress', value: inProgressJobs, color: 'bg-purple-500' },
    { label: 'Completed', value: completedJobs, color: 'bg-green-500' }
  ];
  
  const jobPriorityData = [
    { label: 'High', value: highPriorityJobs, color: 'bg-red-500' },
    { label: 'Medium', value: mediumPriorityJobs, color: 'bg-yellow-500' },
    { label: 'Low', value: lowPriorityJobs, color: 'bg-green-500' }
  ];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Welcome to the Ship Management System</p>
      </div>
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <KPICard
          title="Total Ships"
          value={totalShips}
          icon={<Ship className="h-6 w-6" />}
          color="bg-blue-500"
        />
        <KPICard
          title="Total Components"
          value={totalComponents}
          icon={<Tool className="h-6 w-6" />}
          color="bg-green-500"
        />
        <KPICard
          title="Maintenance Due"
          value={componentsWithOverdueMaintenance}
          icon={<Activity className="h-6 w-6" />}
          color="bg-yellow-500"
        />
        <KPICard
          title="Active Jobs"
          value={openJobs + inProgressJobs}
          icon={<BarChart className="h-6 w-6" />}
          color="bg-purple-500"
        />
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <StatusChart 
          title="Ship Status" 
          data={shipStatusData} 
          total={totalShips} 
        />
        <StatusChart 
          title="Job Status" 
          data={jobStatusData} 
          total={totalJobs} 
        />
        <StatusChart 
          title="Job Priority" 
          data={jobPriorityData} 
          total={totalJobs} 
        />
      </div>
    </div>
  );
};

export default DashboardPage;