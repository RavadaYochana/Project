import React, { useState } from 'react';
import { Ship as ShipIcon, Plus, Search } from 'lucide-react';
import { useShips } from '../contexts/ShipsContext';
import { useComponents } from '../contexts/ComponentsContext';
import { useJobs } from '../contexts/JobsContext';
import ShipCard from '../components/ships/ShipCard';
import ShipForm from '../components/ships/ShipForm';
import Button from '../components/ui/Button';
import { Ship } from '../types';

const ShipsPage: React.FC = () => {
  const { ships, addShip } = useShips();
  const { components } = useComponents();
  const { jobs } = useJobs();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const handleAddShip = (shipData: Omit<Ship, 'id'>) => {
    addShip(shipData);
    setShowAddForm(false);
  };

  // Get component count for a ship
  const getComponentCount = (shipId: string) => {
    return components.filter(component => component.shipId === shipId).length;
  };

  // Get job count for a ship
  const getJobCount = (shipId: string) => {
    return jobs.filter(job => job.shipId === shipId).length;
  };

  // Get pending maintenance count for a ship
  const getPendingMaintenanceCount = (shipId: string) => {
    return jobs.filter(
      job => job.shipId === shipId && (job.status === 'Open' || job.status === 'In Progress')
    ).length;
  };

  // Filter ships based on search
  const filteredShips = ships.filter(ship => 
    ship.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ship.imo.includes(searchTerm) ||
    ship.flag.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center">
              <ShipIcon className="h-6 w-6 mr-2 text-blue-600" />
              Ships
            </h1>
            <p className="text-gray-600">Manage your fleet</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button
              onClick={() => setShowAddForm(!showAddForm)}
              variant="primary"
              icon={<Plus className="h-4 w-4" />}
            >
              Add New Ship
            </Button>
          </div>
        </div>
      </div>

      {showAddForm && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Add New Ship</h2>
          <ShipForm onSubmit={handleAddShip} />
        </div>
      )}
      
      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search ships by name, IMO, or flag..."
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {filteredShips.length === 0 ? (
        <div className="bg-white p-6 text-center rounded-lg shadow-md">
          <p className="text-gray-500">
            {ships.length === 0 
              ? "No ships available. Add your first ship to get started." 
              : "No ships match your search criteria."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredShips.map(ship => (
            <ShipCard
              key={ship.id}
              ship={ship}
              componentCount={getComponentCount(ship.id)}
              jobCount={getJobCount(ship.id)}
              pendingMaintenanceCount={getPendingMaintenanceCount(ship.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ShipsPage;