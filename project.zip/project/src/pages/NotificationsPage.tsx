import React from 'react';
import { Bell, Check } from 'lucide-react';
import { useNotifications } from '../contexts/NotificationsContext';
import NotificationList from '../components/notifications/NotificationList';
import Button from '../components/ui/Button';
import { useNavigate } from 'react-router-dom';
import { useJobs } from '../contexts/JobsContext';

const NotificationsPage: React.FC = () => {
  const { notifications, markAsRead, markAllAsRead, deleteNotification } = useNotifications();
  const { getJobById } = useJobs();
  const navigate = useNavigate();

  const handleViewRelated = (relatedId: string) => {
    const job = getJobById(relatedId);
    if (job) {
      navigate(`/ships/${job.shipId}`);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div>
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center">
              <Bell className="h-6 w-6 mr-2 text-blue-600" />
              Notifications
            </h1>
            <p className="text-gray-600">
              {unreadCount > 0 
                ? `You have ${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` 
                : 'All caught up!'}
            </p>
          </div>
          
          {unreadCount > 0 && (
            <div className="mt-4 md:mt-0">
              <Button
                onClick={markAllAsRead}
                variant="primary"
                icon={<Check className="h-4 w-4" />}
              >
                Mark All as Read
              </Button>
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <NotificationList
          notifications={notifications}
          onMarkAsRead={markAsRead}
          onDelete={deleteNotification}
          onViewRelated={handleViewRelated}
        />
      </div>
    </div>
  );
};

export default NotificationsPage;