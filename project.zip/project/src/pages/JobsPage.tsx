import React, { useState } from 'react';
import { PenTool as Tool, Plus, Filter, X, Search } from 'lucide-react';
import { useJobs } from '../contexts/JobsContext';
import { useShips } from '../contexts/ShipsContext';
import Button from '../components/ui/Button';
import JobList from '../components/jobs/JobList';
import JobForm from '../components/jobs/JobForm';
import { Job } from '../types';

const JobsPage: React.FC = () => {
  const { jobs, getJobById, addJob, updateJob, deleteJob } = useJobs();
  const { ships } = useShips();
  
  const [showAddJob, setShowAddJob] = useState(false);
  const [editingJob, setEditingJob] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    shipId: '',
    status: '',
    priority: ''
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const handleAddJob = (jobData: Omit<Job, 'id'>) => {
    addJob(jobData);
    setShowAddJob(false);
  };

  const handleEditJob = (jobId: string) => {
    setEditingJob(jobId);
    setShowAddJob(true);
  };

  const handleUpdateJob = (jobData: Omit<Job, 'id'>) => {
    if (editingJob) {
      updateJob(editingJob, jobData);
      setEditingJob(null);
      setShowAddJob(false);
    }
  };

  const handleDeleteJob = (jobId: string) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      deleteJob(jobId);
    }
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const resetFilters = () => {
    setFilters({
      shipId: '',
      status: '',
      priority: ''
    });
    setSearchTerm('');
  };

  // Apply filters
  const filteredJobs = jobs.filter(job => {
    let matchesFilters = true;
    
    if (filters.shipId && job.shipId !== filters.shipId) {
      matchesFilters = false;
    }
    
    if (filters.status && job.status !== filters.status) {
      matchesFilters = false;
    }
    
    if (filters.priority && job.priority !== filters.priority) {
      matchesFilters = false;
    }
    
    // Search term - match against the job type
    if (searchTerm && !job.type.toLowerCase().includes(searchTerm.toLowerCase())) {
      matchesFilters = false;
    }
    
    return matchesFilters;
  });

  // Check if any filters are active
  const hasActiveFilters = filters.shipId || filters.status || filters.priority || searchTerm;

  return (
    <div>
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center">
              <Tool className="h-6 w-6 mr-2 text-blue-600" />
              Maintenance Jobs
            </h1>
            <p className="text-gray-600">Manage maintenance schedule</p>
          </div>
          <div className="mt-4 md:mt-0 flex gap-2">
            <Button
              onClick={() => setShowFilters(!showFilters)}
              variant="secondary"
              icon={<Filter className="h-4 w-4" />}
            >
              Filters
            </Button>
            <Button
              onClick={() => {
                setEditingJob(null);
                setShowAddJob(!showAddJob);
              }}
              variant="primary"
              icon={<Plus className="h-4 w-4" />}
            >
              Schedule Job
            </Button>
          </div>
        </div>
      </div>

      {showAddJob && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">
            {editingJob ? 'Edit Maintenance Job' : 'Schedule New Maintenance Job'}
          </h2>
          <JobForm
            initialData={editingJob ? getJobById(editingJob) : undefined}
            onSubmit={editingJob ? handleUpdateJob : handleAddJob}
            isEdit={!!editingJob}
          />
        </div>
      )}
      
      {/* Filters */}
      {showFilters && (
        <div className="bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Filters</h3>
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
              >
                <X className="h-4 w-4 mr-1" />
                Reset filters
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label htmlFor="searchTerm" className="block text-sm font-medium text-gray-700 mb-1">
                Search
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  id="searchTerm"
                  placeholder="Search job type..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="shipId" className="block text-sm font-medium text-gray-700 mb-1">
                Ship
              </label>
              <select
                id="shipId"
                name="shipId"
                value={filters.shipId}
                onChange={handleFilterChange}
                className="block w-full border border-gray-300 rounded-md py-2 text-sm"
              >
                <option value="">All Ships</option>
                {ships.map(ship => (
                  <option key={ship.id} value={ship.id}>
                    {ship.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                id="status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
                className="block w-full border border-gray-300 rounded-md py-2 text-sm"
              >
                <option value="">All Statuses</option>
                <option value="Open">Open</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                Priority
              </label>
              <select
                id="priority"
                name="priority"
                value={filters.priority}
                onChange={handleFilterChange}
                className="block w-full border border-gray-300 rounded-md py-2 text-sm"
              >
                <option value="">All Priorities</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>
          </div>
        </div>
      )}
      
      {/* Results info */}
      <div className="mb-4 text-sm text-gray-500">
        Showing {filteredJobs.length} of {jobs.length} jobs
        {hasActiveFilters && " (filtered)"}
      </div>
      
      {/* Job list */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <JobList
          jobs={filteredJobs}
          onEdit={handleEditJob}
          onDelete={handleDeleteJob}
        />
      </div>
    </div>
  );
};

export default JobsPage;