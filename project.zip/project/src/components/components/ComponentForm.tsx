import React, { useState } from 'react';
import { Component } from '../../types';
import Button from '../ui/Button';

interface ComponentFormProps {
  shipId: string;
  onSubmit: (data: Omit<Component, 'id'>) => void;
  initialData?: Component;
  isEdit?: boolean;
}

const ComponentForm: React.FC<ComponentFormProps> = ({
  shipId,
  onSubmit,
  initialData,
  isEdit = false
}) => {
  const [formData, setFormData] = useState<Omit<Component, 'id'>>({
    shipId: shipId,
    name: initialData?.name || '',
    serialNumber: initialData?.serialNumber || '',
    installDate: initialData?.installDate?.split('T')[0] || '',
    lastMaintenanceDate: initialData?.lastMaintenanceDate?.split('T')[0] || ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Component name is required';
    }
    
    if (!formData.serialNumber.trim()) {
      newErrors.serialNumber = 'Serial number is required';
    }
    
    if (!formData.installDate) {
      newErrors.installDate = 'Installation date is required';
    }
    
    // Validation for lastMaintenanceDate
    // It should be either empty or not before installDate
    if (formData.lastMaintenanceDate && 
        new Date(formData.lastMaintenanceDate) < new Date(formData.installDate)) {
      newErrors.lastMaintenanceDate = 'Last maintenance date cannot be before installation date';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Ensure dates are in ISO format
      const formattedData = {
        ...formData,
        installDate: new Date(formData.installDate).toISOString(),
        lastMaintenanceDate: formData.lastMaintenanceDate 
          ? new Date(formData.lastMaintenanceDate).toISOString() 
          : ''
      };
      
      onSubmit(formattedData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Component Name
          </label>
          <div className="mt-1">
            <input
              type="text"
              name="name"
              id="name"
              value={formData.name}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.name ? 'border-red-300' : ''
              }`}
            />
            {errors.name && (
              <p className="mt-2 text-sm text-red-600">{errors.name}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="serialNumber" className="block text-sm font-medium text-gray-700">
            Serial Number
          </label>
          <div className="mt-1">
            <input
              type="text"
              name="serialNumber"
              id="serialNumber"
              value={formData.serialNumber}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.serialNumber ? 'border-red-300' : ''
              }`}
            />
            {errors.serialNumber && (
              <p className="mt-2 text-sm text-red-600">{errors.serialNumber}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="installDate" className="block text-sm font-medium text-gray-700">
            Installation Date
          </label>
          <div className="mt-1">
            <input
              type="date"
              name="installDate"
              id="installDate"
              value={formData.installDate}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.installDate ? 'border-red-300' : ''
              }`}
            />
            {errors.installDate && (
              <p className="mt-2 text-sm text-red-600">{errors.installDate}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="lastMaintenanceDate" className="block text-sm font-medium text-gray-700">
            Last Maintenance Date
          </label>
          <div className="mt-1">
            <input
              type="date"
              name="lastMaintenanceDate"
              id="lastMaintenanceDate"
              value={formData.lastMaintenanceDate}
              onChange={handleChange}
              max={new Date().toISOString().split('T')[0]}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.lastMaintenanceDate ? 'border-red-300' : ''
              }`}
            />
            {errors.lastMaintenanceDate && (
              <p className="mt-2 text-sm text-red-600">{errors.lastMaintenanceDate}</p>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" variant="primary">
          {isEdit ? 'Update Component' : 'Add Component'}
        </Button>
      </div>
    </form>
  );
};

export default ComponentForm;