import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifications } from '../../contexts/NotificationsContext';
import { Ship, BarChart, Calendar, PenTool as Tool, Bell, Menu, X, LogOut, User, Anchor } from 'lucide-react';

const Navbar: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { unreadCount } = useNotifications();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path 
      ? 'bg-blue-700 text-white' 
      : 'text-blue-100 hover:bg-blue-700 hover:text-white';
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <nav className="bg-blue-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link to="/dashboard" className="flex items-center">
                <Anchor className="h-8 w-8 text-white" />
                <span className="ml-2 text-white font-bold text-lg">ShipManage</span>
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link
                  to="/dashboard"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/dashboard')}`}
                >
                  <div className="flex items-center">
                    <BarChart className="h-4 w-4 mr-1" />
                    Dashboard
                  </div>
                </Link>
                <Link
                  to="/ships"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/ships')}`}
                >
                  <div className="flex items-center">
                    <Ship className="h-4 w-4 mr-1" />
                    Ships
                  </div>
                </Link>
                <Link
                  to="/jobs"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/jobs')}`}
                >
                  <div className="flex items-center">
                    <Tool className="h-4 w-4 mr-1" />
                    Maintenance
                  </div>
                </Link>
                <Link
                  to="/calendar"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${isActive('/calendar')}`}
                >
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    Calendar
                  </div>
                </Link>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
              <Link
                to="/notifications"
                className="p-1 rounded-full text-blue-100 hover:text-white relative"
              >
                <Bell className="h-6 w-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4 bg-red-500 text-white rounded-full text-xs w-5 h-5 flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>

              <div className="ml-3 relative">
                <div className="flex items-center">
                  <div className="ml-3">
                    <div className="text-sm font-medium text-white">
                      {currentUser?.email}
                    </div>
                    <div className="text-xs text-blue-300">
                      {currentUser?.role}
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="ml-3 px-2 py-1 bg-blue-700 rounded-md text-sm text-white flex items-center hover:bg-blue-600"
                >
                  <LogOut className="h-4 w-4 mr-1" />
                  Sign out
                </button>
              </div>
            </div>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={toggleMenu}
              className="bg-blue-700 inline-flex items-center justify-center p-2 rounded-md text-blue-100 hover:text-white hover:bg-blue-600 focus:outline-none"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link
              to="/dashboard"
              className={`block px-3 py-2 rounded-md text-base font-medium ${isActive('/dashboard')}`}
              onClick={() => setIsMenuOpen(false)}
            >
              <div className="flex items-center">
                <BarChart className="h-5 w-5 mr-2" />
                Dashboard
              </div>
            </Link>
            <Link
              to="/ships"
              className={`block px-3 py-2 rounded-md text-base font-medium ${isActive('/ships')}`}
              onClick={() => setIsMenuOpen(false)}
            >
              <div className="flex items-center">
                <Ship className="h-5 w-5 mr-2" />
                Ships
              </div>
            </Link>
            <Link
              to="/jobs"
              className={`block px-3 py-2 rounded-md text-base font-medium ${isActive('/jobs')}`}
              onClick={() => setIsMenuOpen(false)}
            >
              <div className="flex items-center">
                <Tool className="h-5 w-5 mr-2" />
                Maintenance
              </div>
            </Link>
            <Link
              to="/calendar"
              className={`block px-3 py-2 rounded-md text-base font-medium ${isActive('/calendar')}`}
              onClick={() => setIsMenuOpen(false)}
            >
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Calendar
              </div>
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-blue-700">
            <div className="flex items-center px-5">
              <div className="flex-shrink-0">
                <User className="h-10 w-10 rounded-full bg-blue-700 p-2 text-white" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-white">
                  {currentUser?.email}
                </div>
                <div className="text-sm font-medium text-blue-300">
                  {currentUser?.role}
                </div>
              </div>
              <Link
                to="/notifications"
                className="ml-auto flex-shrink-0 p-1 rounded-full text-blue-100 hover:text-white relative"
                onClick={() => setIsMenuOpen(false)}
              >
                <Bell className="h-6 w-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4 bg-red-500 text-white rounded-full text-xs w-5 h-5 flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>
            </div>
            <div className="mt-3 px-2 space-y-1">
              <button
                className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-blue-100 hover:text-white hover:bg-blue-700"
                onClick={handleLogout}
              >
                <div className="flex items-center">
                  <LogOut className="h-5 w-5 mr-2" />
                  Sign out
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;