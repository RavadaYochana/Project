import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isSameMonth, addMonths, subMonths } from 'date-fns';
import { Job } from '../../types';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CalendarProps {
  jobs: Job[];
  onDayClick: (date: Date, jobs: Job[]) => void;
}

const Calendar: React.FC<CalendarProps> = ({ jobs, onDayClick }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };
  
  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };
  
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });
  
  // Get day of week (0 = Sunday, 6 = Saturday)
  const startDay = monthStart.getDay();
  
  // Create array of blanks for the start of the month
  const blanks = Array(startDay).fill(null);
  
  // Get jobs for a specific date
  const getJobsForDate = (date: Date) => {
    return jobs.filter(job => {
      const jobDate = new Date(job.scheduledDate);
      return (
        jobDate.getDate() === date.getDate() &&
        jobDate.getMonth() === date.getMonth() &&
        jobDate.getFullYear() === date.getFullYear()
      );
    });
  };
  
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="flex items-center justify-between px-6 py-4 border-b">
        <h2 className="text-lg font-semibold text-gray-900">
          {format(currentMonth, 'MMMM yyyy')}
        </h2>
        <div className="flex space-x-2">
          <button
            onClick={prevMonth}
            className="p-2 rounded-md hover:bg-gray-100"
            aria-label="Previous month"
          >
            <ChevronLeft className="h-5 w-5 text-gray-500" />
          </button>
          <button
            onClick={nextMonth}
            className="p-2 rounded-md hover:bg-gray-100"
            aria-label="Next month"
          >
            <ChevronRight className="h-5 w-5 text-gray-500" />
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-7 gap-px bg-gray-200">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div
            key={day}
            className="py-2 bg-gray-50 text-center text-sm font-medium text-gray-500"
          >
            {day}
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-7 gap-px bg-gray-200">
        {/* Blanks for start of month */}
        {blanks.map((_, index) => (
          <div key={`blank-${index}`} className="bg-gray-50 h-24 md:h-36" />
        ))}
        
        {/* Days of month */}
        {monthDays.map((day) => {
          const dayJobs = getJobsForDate(day);
          const isCurrentDay = isToday(day);
          const isCurrentMonth = isSameMonth(day, currentMonth);
          
          return (
            <div
              key={day.toString()}
              className={`bg-white h-24 md:h-36 p-2 overflow-y-auto ${
                !isCurrentMonth ? 'bg-gray-50 text-gray-400' : ''
              }`}
              onClick={() => onDayClick(day, dayJobs)}
            >
              <div className="flex justify-between">
                <span
                  className={`inline-flex items-center justify-center w-6 h-6 text-sm ${
                    isCurrentDay
                      ? 'bg-blue-600 text-white rounded-full'
                      : 'text-gray-700'
                  }`}
                >
                  {format(day, 'd')}
                </span>
                {dayJobs.length > 0 && (
                  <span className="text-xs bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded-full">
                    {dayJobs.length}
                  </span>
                )}
              </div>
              
              {/* Show job dots */}
              <div className="mt-1 space-y-1">
                {dayJobs.slice(0, 2).map((job) => (
                  <div
                    key={job.id}
                    className={`text-xs truncate px-1 py-0.5 rounded ${
                      job.priority === 'High'
                        ? 'bg-red-100 text-red-800'
                        : job.priority === 'Medium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {job.type}
                  </div>
                ))}
                {dayJobs.length > 2 && (
                  <div className="text-xs text-gray-500">
                    +{dayJobs.length - 2} more
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Calendar;