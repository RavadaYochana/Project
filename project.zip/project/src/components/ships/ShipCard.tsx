import React from 'react';
import { Ship } from '../../types';
import { Link } from 'react-router-dom';
import { Ship as ShipIcon, PenTool as Tool, AlertCircle } from 'lucide-react';

interface ShipCardProps {
  ship: Ship;
  componentCount: number;
  jobCount: number;
  pendingMaintenanceCount: number;
}

const ShipCard: React.FC<ShipCardProps> = ({ 
  ship, 
  componentCount,
  jobCount,
  pendingMaintenanceCount
}) => {
  // Status colors
  const statusColors = {
    'Active': 'bg-green-100 text-green-800',
    'Under Maintenance': 'bg-yellow-100 text-yellow-800',
    'Inactive': 'bg-red-100 text-red-800'
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-900">{ship.name}</h3>
          <span className={`text-xs px-2 py-1 rounded-full ${statusColors[ship.status as keyof typeof statusColors]}`}>
            {ship.status}
          </span>
        </div>
        
        <div className="text-gray-600 text-sm mb-4">
          <p><span className="font-medium">IMO:</span> {ship.imo}</p>
          <p><span className="font-medium">Flag:</span> {ship.flag}</p>
        </div>
        
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="flex flex-col items-center p-2 bg-blue-50 rounded-md">
            <ShipIcon className="h-5 w-5 text-blue-600 mb-1" />
            <span className="text-xs text-gray-600">Components</span>
            <span className="font-bold text-blue-600">{componentCount}</span>
          </div>
          <div className="flex flex-col items-center p-2 bg-teal-50 rounded-md">
            <Tool className="h-5 w-5 text-teal-600 mb-1" />
            <span className="text-xs text-gray-600">Jobs</span>
            <span className="font-bold text-teal-600">{jobCount}</span>
          </div>
          <div className="flex flex-col items-center p-2 bg-amber-50 rounded-md">
            <AlertCircle className="h-5 w-5 text-amber-600 mb-1" />
            <span className="text-xs text-gray-600">Pending</span>
            <span className="font-bold text-amber-600">{pendingMaintenanceCount}</span>
          </div>
        </div>
        
        <Link
          to={`/ships/${ship.id}`}
          className="block w-full text-center py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md transition-colors"
        >
          View Details
        </Link>
      </div>
    </div>
  );
};

export default ShipCard;