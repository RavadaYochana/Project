import React, { useState } from 'react';
import { Ship } from '../../types';
import Button from '../ui/Button';

interface ShipFormProps {
  onSubmit: (data: Omit<Ship, 'id'>) => void;
  initialData?: Ship;
  isEdit?: boolean;
}

const ShipForm: React.FC<ShipFormProps> = ({ 
  onSubmit, 
  initialData,
  isEdit = false
}) => {
  const [formData, setFormData] = useState<Omit<Ship, 'id'>>({
    name: initialData?.name || '',
    imo: initialData?.imo || '',
    flag: initialData?.flag || '',
    status: initialData?.status || 'Active'
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Ship name is required';
    }
    
    if (!formData.imo.trim()) {
      newErrors.imo = 'IMO number is required';
    } else if (!/^\d{7}$/.test(formData.imo)) {
      newErrors.imo = 'IMO number must be 7 digits';
    }
    
    if (!formData.flag.trim()) {
      newErrors.flag = 'Flag is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Ship Name
          </label>
          <div className="mt-1">
            <input
              type="text"
              name="name"
              id="name"
              value={formData.name}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.name ? 'border-red-300' : ''
              }`}
            />
            {errors.name && (
              <p className="mt-2 text-sm text-red-600">{errors.name}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="imo" className="block text-sm font-medium text-gray-700">
            IMO Number
          </label>
          <div className="mt-1">
            <input
              type="text"
              name="imo"
              id="imo"
              value={formData.imo}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.imo ? 'border-red-300' : ''
              }`}
              placeholder="7 digits"
            />
            {errors.imo && (
              <p className="mt-2 text-sm text-red-600">{errors.imo}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="flag" className="block text-sm font-medium text-gray-700">
            Flag
          </label>
          <div className="mt-1">
            <input
              type="text"
              name="flag"
              id="flag"
              value={formData.flag}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.flag ? 'border-red-300' : ''
              }`}
              placeholder="Country of registration"
            />
            {errors.flag && (
              <p className="mt-2 text-sm text-red-600">{errors.flag}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-700">
            Status
          </label>
          <div className="mt-1">
            <select
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
            >
              <option value="Active">Active</option>
              <option value="Under Maintenance">Under Maintenance</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" variant="primary">
          {isEdit ? 'Update Ship' : 'Add Ship'}
        </Button>
      </div>
    </form>
  );
};

export default ShipForm;