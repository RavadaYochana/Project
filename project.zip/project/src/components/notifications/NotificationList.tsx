import React from 'react';
import { Notification } from '../../types';
import { format, formatDistanceToNow } from 'date-fns';
import { BellRing, Check, X } from 'lucide-react';

interface NotificationListProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onDelete: (id: string) => void;
  onViewRelated?: (id: string) => void;
}

const NotificationList: React.FC<NotificationListProps> = ({ 
  notifications, 
  onMarkAsRead, 
  onDelete,
  onViewRelated
}) => {
  if (notifications.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8">
        <BellRing className="h-12 w-12 text-gray-400 mb-4" />
        <p className="text-gray-500 text-center">No notifications at the moment.</p>
      </div>
    );
  }

  // Helper to get the relative time
  const getRelativeTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return 'Unknown time';
    }
  };

  // Helper to get notification icon color
  const getIconColor = (type: string) => {
    switch (type) {
      case 'Job Created':
        return 'text-blue-500';
      case 'Job Updated':
        return 'text-yellow-500';
      case 'Job Completed':
        return 'text-green-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="divide-y divide-gray-200">
      {notifications.map((notification) => (
        <div 
          key={notification.id} 
          className={`p-4 ${notification.read ? 'bg-white' : 'bg-blue-50'} hover:bg-gray-50 transition-colors duration-150`}
        >
          <div className="flex items-start">
            <div className={`flex-shrink-0 ${getIconColor(notification.type)}`}>
              <BellRing className="h-5 w-5" />
            </div>
            
            <div className="ml-3 flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-900">
                  {notification.type}
                </p>
                <div className="ml-2 flex-shrink-0 flex">
                  {!notification.read && (
                    <button
                      onClick={() => onMarkAsRead(notification.id)}
                      className="bg-blue-100 text-blue-600 hover:bg-blue-200 inline-flex p-1 rounded-full"
                      title="Mark as read"
                    >
                      <Check className="h-4 w-4" />
                    </button>
                  )}
                  <button
                    onClick={() => onDelete(notification.id)}
                    className="ml-1 bg-red-100 text-red-600 hover:bg-red-200 inline-flex p-1 rounded-full"
                    title="Delete"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <p className="mt-1 text-sm text-gray-700">
                {notification.message}
              </p>
              <div className="mt-2 flex items-center justify-between">
                <p className="text-xs text-gray-500">
                  {getRelativeTime(notification.date)}
                </p>
                {notification.relatedId && onViewRelated && (
                  <button
                    onClick={() => onViewRelated(notification.relatedId!)}
                    className="text-xs text-blue-600 hover:text-blue-800"
                  >
                    View Details
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default NotificationList;