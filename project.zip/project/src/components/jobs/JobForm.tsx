import React, { useState, useEffect } from 'react';
import { Job, Component } from '../../types';
import { useComponents } from '../../contexts/ComponentsContext';
import { useShips } from '../../contexts/ShipsContext';
import { getUsers } from '../../utils/localStorage';
import Button from '../ui/Button';

interface JobFormProps {
  onSubmit: (data: Omit<Job, 'id'>) => void;
  initialData?: Job;
  isEdit?: boolean;
  componentId?: string;
  shipId?: string;
}

const JobForm: React.FC<JobFormProps> = ({
  onSubmit,
  initialData,
  isEdit = false,
  componentId,
  shipId
}) => {
  const { components, getComponentById } = useComponents();
  const { ships, getShipById } = useShips();
  const [engineers, setEngineers] = useState<{ id: string; email: string }[]>([]);
  const [shipComponents, setShipComponents] = useState<Component[]>([]);

  const [formData, setFormData] = useState<Omit<Job, 'id'>>({
    componentId: initialData?.componentId || componentId || '',
    shipId: initialData?.shipId || shipId || '',
    type: initialData?.type || '',
    priority: initialData?.priority || 'Medium',
    status: initialData?.status || 'Open',
    assignedEngineerId: initialData?.assignedEngineerId || '',
    scheduledDate: initialData?.scheduledDate?.split('T')[0] || ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Load engineers (users with Engineer role)
  useEffect(() => {
    const users = getUsers();
    const engineerUsers = users
      .filter(user => user.role === 'Engineer')
      .map(user => ({ id: user.id, email: user.email }));
    
    setEngineers(engineerUsers);
    
    // Set default engineer if none is selected
    if (!formData.assignedEngineerId && engineerUsers.length > 0) {
      setFormData(prev => ({
        ...prev,
        assignedEngineerId: engineerUsers[0].id
      }));
    }
  }, [formData.assignedEngineerId]);

  // Update ship components when shipId changes
  useEffect(() => {
    if (formData.shipId) {
      const filteredComponents = components.filter(
        component => component.shipId === formData.shipId
      );
      setShipComponents(filteredComponents);
      
      // If component is not in this ship or not set, set the first one
      const componentBelongsToShip = filteredComponents.some(
        c => c.id === formData.componentId
      );
      
      if (!componentBelongsToShip && filteredComponents.length > 0) {
        setFormData(prev => ({
          ...prev,
          componentId: filteredComponents[0].id
        }));
      }
    }
  }, [formData.shipId, components, formData.componentId]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.shipId) {
      newErrors.shipId = 'Ship is required';
    }
    
    if (!formData.componentId) {
      newErrors.componentId = 'Component is required';
    }
    
    if (!formData.type.trim()) {
      newErrors.type = 'Job type is required';
    }
    
    if (!formData.scheduledDate) {
      newErrors.scheduledDate = 'Scheduled date is required';
    } else {
      const scheduledDate = new Date(formData.scheduledDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (scheduledDate < today) {
        newErrors.scheduledDate = 'Scheduled date cannot be in the past';
      }
    }
    
    if (!formData.assignedEngineerId) {
      newErrors.assignedEngineerId = 'Assigned engineer is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Ensure dates are in ISO format
      const formattedData = {
        ...formData,
        scheduledDate: new Date(formData.scheduledDate).toISOString(),
      };
      
      onSubmit(formattedData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <div>
          <label htmlFor="shipId" className="block text-sm font-medium text-gray-700">
            Ship
          </label>
          <div className="mt-1">
            <select
              id="shipId"
              name="shipId"
              value={formData.shipId}
              onChange={handleChange}
              disabled={!!shipId || isEdit}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.shipId ? 'border-red-300' : ''
              } ${(!!shipId || isEdit) ? 'bg-gray-100' : ''}`}
            >
              <option value="">Select a ship</option>
              {ships.map(ship => (
                <option key={ship.id} value={ship.id}>
                  {ship.name} - {ship.imo}
                </option>
              ))}
            </select>
            {errors.shipId && (
              <p className="mt-2 text-sm text-red-600">{errors.shipId}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="componentId" className="block text-sm font-medium text-gray-700">
            Component
          </label>
          <div className="mt-1">
            <select
              id="componentId"
              name="componentId"
              value={formData.componentId}
              onChange={handleChange}
              disabled={!formData.shipId || !!componentId || isEdit}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.componentId ? 'border-red-300' : ''
              } ${(!formData.shipId || !!componentId || isEdit) ? 'bg-gray-100' : ''}`}
            >
              <option value="">Select a component</option>
              {shipComponents.map(component => (
                <option key={component.id} value={component.id}>
                  {component.name} - {component.serialNumber}
                </option>
              ))}
            </select>
            {errors.componentId && (
              <p className="mt-2 text-sm text-red-600">{errors.componentId}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="type" className="block text-sm font-medium text-gray-700">
            Job Type
          </label>
          <div className="mt-1">
            <input
              type="text"
              name="type"
              id="type"
              value={formData.type}
              onChange={handleChange}
              placeholder="e.g., Inspection, Repair, Replacement"
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.type ? 'border-red-300' : ''
              }`}
            />
            {errors.type && (
              <p className="mt-2 text-sm text-red-600">{errors.type}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="priority" className="block text-sm font-medium text-gray-700">
            Priority
          </label>
          <div className="mt-1">
            <select
              id="priority"
              name="priority"
              value={formData.priority}
              onChange={handleChange}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
            >
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-700">
            Status
          </label>
          <div className="mt-1">
            <select
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
            >
              <option value="Open">Open</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="assignedEngineerId" className="block text-sm font-medium text-gray-700">
            Assigned Engineer
          </label>
          <div className="mt-1">
            <select
              id="assignedEngineerId"
              name="assignedEngineerId"
              value={formData.assignedEngineerId}
              onChange={handleChange}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.assignedEngineerId ? 'border-red-300' : ''
              }`}
            >
              <option value="">Select an engineer</option>
              {engineers.map(engineer => (
                <option key={engineer.id} value={engineer.id}>
                  {engineer.email}
                </option>
              ))}
            </select>
            {errors.assignedEngineerId && (
              <p className="mt-2 text-sm text-red-600">{errors.assignedEngineerId}</p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="scheduledDate" className="block text-sm font-medium text-gray-700">
            Scheduled Date
          </label>
          <div className="mt-1">
            <input
              type="date"
              name="scheduledDate"
              id="scheduledDate"
              value={formData.scheduledDate}
              onChange={handleChange}
              min={new Date().toISOString().split('T')[0]}
              className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md ${
                errors.scheduledDate ? 'border-red-300' : ''
              }`}
            />
            {errors.scheduledDate && (
              <p className="mt-2 text-sm text-red-600">{errors.scheduledDate}</p>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button type="submit" variant="primary">
          {isEdit ? 'Update Job' : 'Create Job'}
        </Button>
      </div>
    </form>
  );
};

export default JobForm;